var divBox = document.getElementsByClassName('img-wrap');
console.log(box);
var imgObj = divBox.getElementsByTagName('img');


